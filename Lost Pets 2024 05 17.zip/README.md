Repo for Lost Pets mod, to be able to work on it from all devices.
#Warning: poor quality
Warning: SOLID is not presented here.
